import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase padre de la bala
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bala extends Actor
{
   public int band_dir = 0;
    
    
    public void act() 
    {
        // Add your action code here.
    }    
}
    
