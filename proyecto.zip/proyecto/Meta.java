import greenfoot.*;

/**
 * Write a description of class compu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)()
 */
public class Meta extends Actor
{
    /**
     * Act - do whatever the compu wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Meta()
    {
       
    }
    
    public void act() 
    {
        if(isTouching(Jugador.class))
        {
            
        }
    
}
}
